// config.js - Clean Configuration (Refactored)
// This file now only exports the settings function, logic moved to SettingsManager

import SettingsManager from "./core/SettingsManager.js";

// Create settings manager instance
const settingsManager = new SettingsManager();

// Export settings function for backwards compatibility
export default () => settingsManager.getSettings();