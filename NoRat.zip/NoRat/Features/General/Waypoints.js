// features/general/Waypoints.js - Waypoints Feature
import { sendMessage } from "../../utils/chat.js";
import { getDistance } from "../../utils/functions.js";

export default class Waypoints {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.waypoints = new Map();
        this.mobWaypoints = new Map();
        this.init();
    }
    
    init() {
        const waypointTime = this.settingsManager.getSetting("drawWaypoint");
        if (!waypointTime || waypointTime <= 0) return;
        
        this.registerEventListeners();
        sendMessage("Waypoints initialized");
    }
    
    registerEventListeners() {
        // Detect coordinate messages in chat (Patcher format)
        register("chat", (x, y, z) => {
            this.onCoordinateMessage(x, y, z, false);
        }).setChatCriteria("x: ${x}, y: ${y}, z: ${z}");
        
        // Alternative coordinate format
        register("chat", (x, y, z) => {
            this.onCoordinateMessage(x, y, z, false);
        }).setChatCriteria("${x} ${y} ${z}");
        
        // Mob waypoint format (shorter duration)
        register("chat", (mobName, x, y, z) => {
            this.onCoordinateMessage(x, y, z, true, mobName);
        }).setChatCriteria("${mobName} at ${x} ${y} ${z}");
        
        // Render waypoints
        register("renderWorld", () => {
            this.renderWaypoints();
        });
        
        // Clean up expired waypoints
        register("tick", () => {
            this.cleanupExpiredWaypoints();
        });
    }
    
    onCoordinateMessage(x, y, z, isMob = false, mobName = null) {
        const waypointTime = this.settingsManager.getSetting("drawWaypoint");
        if (!waypointTime || waypointTime <= 0) return;
        
        try {
            const coordX = parseInt(x);
            const coordY = parseInt(y);
            const coordZ = parseInt(z);
            
            if (isNaN(coordX) || isNaN(coordY) || isNaN(coordZ)) return;
            
            const waypoint = {
                x: coordX,
                y: coordY,
                z: coordZ,
                timestamp: Date.now(),
                duration: isMob ? (waypointTime * 1000 / 3) : (waypointTime * 1000), // Mob waypoints last 1/3 as long
                name: mobName || `Waypoint`,
                isMob: isMob
            };
            
            const key = `${coordX}_${coordY}_${coordZ}`;
            
            if (isMob) {
                this.mobWaypoints.set(key, waypoint);
            } else {
                this.waypoints.set(key, waypoint);
            }
            
            sendMessage(`Waypoint created at ${coordX}, ${coordY}, ${coordZ}${mobName ? ` (${mobName})` : ""}`);
            
        } catch (error) {
            console.error("Error creating waypoint:", error);
        }
    }
    
    renderWaypoints() {
        const waypointTime = this.settingsManager.getSetting("drawWaypoint");
        if (!waypointTime || waypointTime <= 0) return;
        
        try {
            // Render regular waypoints
            this.waypoints.forEach((waypoint) => {
                this.renderWaypoint(waypoint, 0x00FF00); // Green
            });
            
            // Render mob waypoints
            this.mobWaypoints.forEach((waypoint) => {
                this.renderWaypoint(waypoint, 0xFF0000); // Red
            });
            
        } catch (error) {
            console.error("Error rendering waypoints:", error);
        }
    }
    
    renderWaypoint(waypoint, color) {
        try {
            const playerX = Player.getX();
            const playerY = Player.getY();
            const playerZ = Player.getZ();
            
            const distance = getDistance(playerX, playerY, playerZ, waypoint.x, waypoint.y, waypoint.z);
            
            // Don't render if too close (less than 5 blocks)
            if (distance < 5) return;
            
            // Calculate remaining time
            const elapsed = Date.now() - waypoint.timestamp;
            const remaining = Math.max(0, waypoint.duration - elapsed);
            const remainingSeconds = Math.ceil(remaining / 1000);
            
            if (remaining <= 0) return; // Will be cleaned up next tick
            
            // Render the waypoint
            const x = waypoint.x + 0.5;
            const y = waypoint.y + 1;
            const z = waypoint.z + 0.5;
            
            // Draw a beacon-like effect
            Tessellator.begin(7).colorize(color >> 16 & 255, color >> 8 & 255, color & 255, 100);
            Tessellator.pos(x - 0.5, y, z - 0.5).tex(0, 0);
            Tessellator.pos(x + 0.5, y, z - 0.5).tex(1, 0);
            Tessellator.pos(x + 0.5, y + 2, z - 0.5).tex(1, 1);
            Tessellator.pos(x - 0.5, y + 2, z - 0.5).tex(0, 1);
            Tessellator.draw();
            
            // Draw text label
            const distanceText = `${Math.floor(distance)}m`;
            const timeText = `${remainingSeconds}s`;
            const nameText = waypoint.name;
            
            Tessellator.drawString(nameText, x, y + 2.5, z, color, true, 1.0, false);
            Tessellator.drawString(distanceText, x, y + 2.2, z, 0xFFFFFF, true, 0.8, false);
            Tessellator.drawString(timeText, x, y + 1.9, z, 0xFFFF00, true, 0.6, false);
            
        } catch (error) {
            console.error("Error rendering individual waypoint:", error);
        }
    }
    
    cleanupExpiredWaypoints() {
        const currentTime = Date.now();
        
        // Clean regular waypoints
        for (const [key, waypoint] of this.waypoints) {
            if (currentTime - waypoint.timestamp > waypoint.duration) {
                this.waypoints.delete(key);
            }
        }
        
        // Clean mob waypoints
        for (const [key, waypoint] of this.mobWaypoints) {
            if (currentTime - waypoint.timestamp > waypoint.duration) {
                this.mobWaypoints.delete(key);
            }
        }
    }
    
    clearAllWaypoints() {
        this.waypoints.clear();
        this.mobWaypoints.clear();
        sendMessage("All waypoints cleared");
    }
    
    cleanup() {
        this.clearAllWaypoints();
        sendMessage("Waypoints cleaned up");
    }
}