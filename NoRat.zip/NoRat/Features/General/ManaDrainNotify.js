// features/general/ManaDrainNotify.js - Mana Drain Notification Feature
import { sendMessage } from "../../utils/chat.js";

export default class ManaDrainNotify {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("ManaDrainNotify")) return;
        
        this.registerEventListeners();
        sendMessage("ManaDrainNotify initialized");
    }
    
    registerEventListeners() {
        // Register mana drain detection
        register("chat", (amount) => {
            this.onManaDrain(amount);
        }).setChatCriteria("You drained ${amount} Mana from your opponent!");
        
        // Alternative pattern for different mana drain messages
        register("chat", (amount) => {
            this.onManaDrain(amount);
        }).setChatCriteria("Drained ${amount} Mana!");
        
        // Pattern for Mana Vampire enchant
        register("chat", (amount) => {
            this.onManaDrain(amount);
        }).setChatCriteria("${amount} Mana drained!");
    }
    
    onManaDrain(amount) {
        if (!this.settingsManager.getSetting("ManaDrainNotify")) return;
        
        try {
            const manaAmount = parseInt(amount.replace(/,/g, ''));
            
            if (manaAmount > 0) {
                // Send message in party chat
                ChatLib.command(`pc Drained ${amount} Mana!`);
            }
        } catch (error) {
            console.error("Error processing mana drain amount:", error);
        }
    }
    
    cleanup() {
        sendMessage("ManaDrainNotify cleaned up");
    }
}