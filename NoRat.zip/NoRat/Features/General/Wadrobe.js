// features/general/Wardrobe.js - Wardrobe Keybind Feature
import { sendMessage, sendError } from "../../utils/chat.js";
import { C0EPacketClickWindow } from "../../utils/constants.js";

export default class Wardrobe {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.inWardrobeGui = false;
        this.wardrobeSlots = {
            1: 36, 2: 37, 3: 38, 4: 39, 5: 40,
            6: 41, 7: 42, 8: 43, 9: 44
        };
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("enableWd")) return;
        
        this.registerEventListeners();
        sendMessage("Wardrobe keybinds initialized");
    }
    
    registerEventListeners() {
        // Detect when wardrobe GUI is opened
        register("guiOpened", (event) => {
            this.onGuiOpened(event);
        });
        
        // Detect when GUI is closed
        register("guiClosed", (event) => {
            this.onGuiClosed(event);
        });
        
        // Handle key presses in wardrobe
        register("tick", () => {
            this.handleKeybinds();
        });
    }
    
    onGuiOpened(event) {
        const gui = event.gui;
        if (!gui) return;
        
        // Check if it's a wardrobe GUI by looking at the title
        try {
            const container = Player.getContainer();
            if (!container) return;
            
            const containerName = container.getName();
            if (containerName && containerName.toLowerCase().includes("wardrobe")) {
                this.inWardrobeGui = true;
                sendMessage("Wardrobe GUI detected - Keybinds active");
            }
        } catch (error) {
            // Ignore errors in GUI detection
        }
    }
    
    onGuiClosed(event) {
        this.inWardrobeGui = false;
    }
    
    handleKeybinds() {
        if (!this.inWardrobeGui) return;
        if (!this.settingsManager.getSetting("enableWd")) return;
        
        // Check each wardrobe keybind
        for (let i = 1; i <= 9; i++) {
            const keyCode = this.settingsManager.getSetting(`wardrobe_${i}`);
            if (keyCode && keyCode > 0 && this.isKeyPressed(keyCode)) {
                this.equipWardrobe(i);
            }
        }
    }
    
    isKeyPressed(keyCode) {
        try {
            const KeyboardClass = Java.type("org.lwjgl.input.Keyboard");
            return KeyboardClass.isKeyDown(keyCode);
        } catch (error) {
            return false;
        }
    }
    
    equipWardrobe(wardrobeNumber) {
        if (!this.inWardrobeGui) return;
        
        try {
            const slot = this.wardrobeSlots[wardrobeNumber];
            if (!slot) return;
            
            // Click the wardrobe slot
            const container = Player.getContainer();
            if (!container) return;
            
            // Simulate clicking the wardrobe slot
            const windowId = container.getWindowId();
            const clickedItem = container.getStackInSlot(slot);
            
            if (clickedItem) {
                // Send click packet
                const packet = new C0EPacketClickWindow(
                    windowId,
                    slot,
                    0, // Left click
                    0, // Click type
                    clickedItem,
                    0 // Transaction id
                );
                
                Client.sendPacket(packet);
                
                // Play sound if enabled
                if (this.settingsManager.getSetting("WardrobeSound")) {
                    const soundString = this.settingsManager.getSetting("WardrobeSoundString") || "random.click";
                    try {
                        World.playSound(soundString, 1.0, 1.0);
                    } catch (soundError) {
                        console.error("Wardrobe sound error:", soundError);
                    }
                }
                
                sendMessage(`Equipped wardrobe #${wardrobeNumber}`);
                
                // Auto close wardrobe if enabled
                if (this.settingsManager.getSetting("AutoCloseWardrobe")) {
                    setTimeout(() => {
                        Player.getPlayer().closeScreen();
                    }, 100);
                }
            }
            
        } catch (error) {
            sendError(`Failed to equip wardrobe #${wardrobeNumber}`);
            console.error("Wardrobe equip error:", error);
        }
    }
    
    cleanup() {
        this.inWardrobeGui = false;
        sendMessage("Wardrobe cleaned up");
    }
}