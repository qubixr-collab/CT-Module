// features/general/PartyJoinSound.js - Party Join Sound Feature
import { sendMessage, sendError } from "../../utils/chat.js";

export default class PartyJoinSound {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("PartyJoinSound")) return;
        
        this.registerEventListeners();
        sendMessage("PartyJoinSound initialized");
    }
    
    registerEventListeners() {
        // Primary party join pattern
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("${playerName} joined the party.");
        
        // Alternative party join patterns
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("Party > ${playerName} joined the party!");
        
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("[Party] ${playerName} joined the party!");
        
        // Hypixel specific patterns
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("${playerName} has joined the party!");
    }
    
    onPartyJoin(playerName) {
        if (!this.settingsManager.getSetting("PartyJoinSound")) return;
        
        const soundString = this.settingsManager.getSetting("PartyJoinSoundString") || "note.pling";
        
        try {
            // Play the sound
            World.playSound(soundString, 1.0, 1.0);
            
            // Optional: Show a message
            sendMessage(`${playerName} joined the party!`);
            
        } catch (error) {
            sendError(`Failed to play sound: ${soundString}`);
            console.error("Party join sound error:", error);
        }
    }
    
    cleanup() {
        sendMessage("PartyJoinSound cleaned up");
    }
}