// features/cheatos/AutoClicker.js - Complete AutoClicker Implementation
import { sendMessage, sendError, sendSuccess } from "../../utils/chat.js";

export default class AutoClicker {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        
        // AutoClicker state
        this.leftClickerActive = false;
        this.rightClickerActive = false;
        this.leftClickInterval = null;
        this.rightClickInterval = null;
        
        // Key tracking
        this.keyPressed = false;
        
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("enableAutoClicker")) return;
        
        this.registerEvents();
        sendMessage("AutoClicker initialized");
    }
    
    registerEvents() {
        // Key press handler
        register("tick", () => {
            this.handleKeyPress();
        });
        
        // Cleanup on world unload
        register("worldUnload", () => {
            this.stopAllClickers();
        });
    }
    
    handleKeyPress() {
        const keyCode = this.settingsManager.getSetting("autoClickerKey");
        if (!keyCode || keyCode <= 0) return;
        
        const isKeyDown = this.isKeyDown(keyCode);
        const activationType = this.settingsManager.getSetting("autoClickerType");
        
        if (activationType === 0) { // Hold mode
            if (isKeyDown && !this.keyPressed) {
                this.keyPressed = true;
                this.startClicking();
            } else if (!isKeyDown && this.keyPressed) {
                this.keyPressed = false;
                this.stopAllClickers();
            }
        } else { // Toggle mode
            if (isKeyDown && !this.keyPressed) {
                this.keyPressed = true;
                this.toggleClicking();
            } else if (!isKeyDown) {
                this.keyPressed = false;
            }
        }
    }
    
    isKeyDown(keyCode) {
        try {
            const KeyboardClass = Java.type("org.lwjgl.input.Keyboard");
            return KeyboardClass.isKeyDown(keyCode);
        } catch (error) {
            return false;
        }
    }
    
    startClicking() {
        const mode = this.settingsManager.getSetting("autoClickerMode");
        
        switch (mode) {
            case 0: // Left
                this.startLeftClicker();
                break;
            case 1: // Right
                this.startRightClicker();
                break;
            case 2: // Both
                this.startLeftClicker();
                this.startRightClicker();
                break;
        }
    }
    
    toggleClicking() {
        const mode = this.settingsManager.getSetting("autoClickerMode");
        
        switch (mode) {
            case 0: // Left
                this.toggleLeftClicker();
                break;
            case 1: // Right
                this.toggleRightClicker();
                break;
            case 2: // Both
                this.toggleBothClickers();
                break;
        }
    }
    
    startLeftClicker() {
        if (this.leftClickerActive) return;
        
        this.leftClickerActive = true;
        const cps = this.settingsManager.getSetting("autoClickerCPS");
        const delay = 1000 / cps;
        
        this.leftClickInterval = setInterval(() => {
            if (!this.leftClickerActive) return;
            
            try {
                // Simulate left click
                Client.getMinecraft().field_71474_y.field_74312_F.func_74506_a(); // keyBindAttack.onTick()
            } catch (error) {
                // Fallback method
                try {
                    Robot.mousePress(16); // InputEvent.BUTTON1_DOWN_MASK
                    Robot.mouseRelease(16);
                } catch (robotError) {
                    // If both methods fail, stop the clicker
                    this.stopLeftClicker();
                    sendError("Left clicker failed to click!");
                }
            }
        }, delay);
        
        sendSuccess(`Left clicker started at ${cps} CPS`);
    }
    
    startRightClicker() {
        if (this.rightClickerActive) return;
        
        this.rightClickerActive = true;
        const cps = this.settingsManager.getSetting("autoClickerCPS");
        const delay = 1000 / cps;
        
        this.rightClickInterval = setInterval(() => {
            if (!this.rightClickerActive) return;
            
            try {
                // Simulate right click
                Client.getMinecraft().field_71474_y.field_74313_G.func_74506_a(); // keyBindUseItem.onTick()
            } catch (error) {
                // Fallback method
                try {
                    Robot.mousePress(4); // InputEvent.BUTTON3_DOWN_MASK
                    Robot.mouseRelease(4);
                } catch (robotError) {
                    // If both methods fail, stop the clicker
                    this.stopRightClicker();
                    sendError("Right clicker failed to click!");
                }
            }
        }, delay);
        
        sendSuccess(`Right clicker started at ${cps} CPS`);
    }
    
    stopLeftClicker() {
        if (!this.leftClickerActive) return;
        
        this.leftClickerActive = false;
        if (this.leftClickInterval) {
            clearInterval(this.leftClickInterval);
            this.leftClickInterval = null;
        }
        
        sendMessage("Left clicker stopped");
    }
    
    stopRightClicker() {
        if (!this.rightClickerActive) return;
        
        this.rightClickerActive = false;
        if (this.rightClickInterval) {
            clearInterval(this.rightClickInterval);
            this.rightClickInterval = null;
        }
        
        sendMessage("Right clicker stopped");
    }
    
    stopAllClickers() {
        this.stopLeftClicker();
        this.stopRightClicker();
    }
    
    // Command interface methods
    toggleLeftClicker() {
        if (this.leftClickerActive) {
            this.stopLeftClicker();
        } else {
            this.startLeftClicker();
        }
    }
    
    toggleRightClicker() {
        if (this.rightClickerActive) {
            this.stopRightClicker();
        } else {
            this.startRightClicker();
        }
    }
    
    toggleBothClickers() {
        const bothActive = this.leftClickerActive && this.rightClickerActive;
        
        if (bothActive) {
            this.stopAllClickers();
        } else {
            this.startLeftClicker();
            this.startRightClicker();
        }
    }
    
    showStatus() {
        const cps = this.settingsManager.getSetting("autoClickerCPS");
        const mode = this.settingsManager.getSetting("autoClickerMode");
        const type = this.settingsManager.getSetting("autoClickerType");
        const keyCode = this.settingsManager.getSetting("autoClickerKey");
        
        const modeNames = ["Left", "Right", "Both"];
        const typeNames = ["Hold", "Toggle"];
        
        sendMessage("AutoClicker Status:");
        ChatLib.chat(`&7Mode: &f${modeNames[mode]}`);
        ChatLib.chat(`&7Type: &f${typeNames[type]}`);
        ChatLib.chat(`&7CPS: &f${cps}`);
        ChatLib.chat(`&7Keybind: &f${this.getKeyName(keyCode)}`);
        ChatLib.chat(`&7Left Clicker: ${this.leftClickerActive ? "&aActive" : "&cInactive"}`);
        ChatLib.chat(`&7Right Clicker: ${this.rightClickerActive ? "&aActive" : "&cInactive"}`);
    }
    
    getKeyName(keyCode) {
        if (!keyCode || keyCode <= 0) return "None";
        
        try {
            const KeyboardClass = Java.type("org.lwjgl.input.Keyboard");
            return KeyboardClass.getKeyName(keyCode);
        } catch (error) {
            return `Key${keyCode}`;
        }
    }
    
    cleanup() {
        this.stopAllClickers();
        sendMessage("AutoClicker cleaned up");
    }
}