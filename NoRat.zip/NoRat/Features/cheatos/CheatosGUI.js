// features/cheatos/CheatosGUI.js - Cheatos GUI Overlay Feature
import { sendMessage } from "../../utils/chat.js";

export default class CheatosGUI {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.overlayVisible = false;
        this.guiX = 10;
        this.guiY = 10;
        this.guiWidth = 200;
        this.guiHeight = 150;
        this.keyStates = new Map();
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("enableCheatosGUI")) return;
        
        this.registerEventListeners();
        sendMessage("CheatosGUI initialized");
    }
    
    registerEventListeners() {
        // Toggle keybind handler
        register("tick", () => {
            this.handleToggleKey();
        });
        
        // Render overlay
        register("renderOverlay", () => {
            this.renderOverlay();
        });
    }
    
    handleToggleKey() {
        const toggleKey = this.settingsManager.getSetting("cheatosToggleKey");
        if (!toggleKey || toggleKey <= 0) return;
        
        if (this.isKeyPressed(toggleKey)) {
            this.toggleOverlay();
        }
    }
    
    isKeyPressed(keyCode) {
        try {
            const KeyboardClass = Java.type("org.lwjgl.input.Keyboard");
            
            const currentState = KeyboardClass.isKeyDown(keyCode);
            const lastState = this.keyStates.get(keyCode) || false;
            
            this.keyStates.set(keyCode, currentState);
            
            // Return true only on key press (not hold)
            return currentState && !lastState;
        } catch (error) {
            return false;
        }
    }
    
    toggleOverlay() {
        if (!this.settingsManager.getSetting("enableCheatosGUI")) return;
        
        this.overlayVisible = !this.overlayVisible;
        sendMessage(`Cheatos GUI ${this.overlayVisible ? "enabled" : "disabled"}`);
    }
    
    renderOverlay() {
        if (!this.settingsManager.getSetting("enableCheatosGUI")) return;
        if (!this.settingsManager.getSetting("cheatosOverlay")) return;
        if (!this.overlayVisible) return;
        
        try {
            this.drawGUI();
        } catch (error) {
            console.error("Error rendering Cheatos GUI:", error);
        }
    }
    
    drawGUI() {
        const opacity = this.settingsManager.getSetting("cheatosOpacity") || 80;
        const color = this.settingsManager.getSetting("cheatosColor") || [255, 100, 100, 255];
        
        // Calculate alpha from opacity percentage
        const alpha = Math.floor((opacity / 100) * 255);
        const backgroundColor = (alpha << 24) | (color[0] << 16) | (color[1] << 8) | color[2];
        
        // Draw background
        Renderer.drawRect(backgroundColor, this.guiX, this.guiY, this.guiWidth, this.guiHeight);
        
        // Draw border
        const borderColor = 0xFFFFFFFF;
        this.drawBorder(borderColor);
        
        // Draw title
        const titleText = "§c§lCheatos GUI";
        Renderer.drawString(titleText, this.guiX + 10, this.guiY + 10, 0xFFFFFF);
        
        // Draw AutoClicker status
        this.drawAutoClickerStatus();
        
        // Draw keybind info
        this.drawKeybindInfo();
        
        // Draw instructions
        this.drawInstructions();
    }
    
    drawBorder(color) {
        const thickness = 2;
        
        // Top
        Renderer.drawRect(color, this.guiX, this.guiY, this.guiWidth, thickness);
        // Bottom
        Renderer.drawRect(color, this.guiX, this.guiY + this.guiHeight - thickness, this.guiWidth, thickness);
        // Left
        Renderer.drawRect(color, this.guiX, this.guiY, thickness, this.guiHeight);
        // Right
        Renderer.drawRect(color, this.guiX + this.guiWidth - thickness, this.guiY, thickness, this.guiHeight);
    }
    
    drawAutoClickerStatus() {
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        let yOffset = 35;
        
        // AutoClicker enabled status
        const enabled = this.settingsManager.getSetting("enableAutoClicker");
        const statusText = `AutoClicker: ${enabled ? "§aEnabled" : "§cDisabled"}`;
        Renderer.drawString(statusText, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
        yOffset += 15;
        
        if (enabled && autoClicker) {
            // CPS
            const cps = this.settingsManager.getSetting("autoClickerCPS");
            Renderer.drawString(`CPS: §e${cps}`, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
            yOffset += 15;
            
            // Left clicker status
            const leftActive = autoClicker.leftClickerActive;
            const leftStatus = `Left: ${leftActive ? "§aActive" : "§cInactive"}`;
            Renderer.drawString(leftStatus, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
            yOffset += 15;
            
            // Right clicker status
            const rightActive = autoClicker.rightClickerActive;
            const rightStatus = `Right: ${rightActive ? "§aActive" : "§cInactive"}`;
            Renderer.drawString(rightStatus, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
            yOffset += 15;
        }
    }
    
    drawKeybindInfo() {
        const autoClickerKey = this.settingsManager.getSetting("autoClickerKey");
        const toggleKey = this.settingsManager.getSetting("cheatosToggleKey");
        
        let yOffset = 100;
        
        if (autoClickerKey && autoClickerKey > 0) {
            const keyName = this.getKeyName(autoClickerKey);
            Renderer.drawString(`AC Key: §b${keyName}`, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
            yOffset += 15;
        }
        
        if (toggleKey && toggleKey > 0) {
            const keyName = this.getKeyName(toggleKey);
            Renderer.drawString(`GUI Key: §b${keyName}`, this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
            yOffset += 15;
        }
    }
    
    drawInstructions() {
        let yOffset = 130;
        Renderer.drawString("§7Press keys to toggle", this.guiX + 10, this.guiY + yOffset, 0xFFFFFF);
    }
    
    getKeyName(keyCode) {
        try {
            const KeyboardClass = Java.type("org.lwjgl.input.Keyboard");
            return KeyboardClass.getKeyName(keyCode) || "Unknown";
        } catch (error) {
            return "Key " + keyCode;
        }
    }
}