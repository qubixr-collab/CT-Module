// features/webhook/ItemValueChecker.js - Handles item price checking
import { sendError } from "../../utils/chat.js";

export default class ItemValueChecker {
    constructor() {
        this.rareItems = this.loadRareItems();
        this.cache = new Map();
        this.cacheExpiry = 300000; // 5 minutes
    }
    
    /**
     * Check the value of an item
     * @param {string} itemName - Name of the item
     * @param {Function} callback - Callback function with value
     */
    checkItemValue(itemName, callback) {
        const cleanName = this.cleanItemName(itemName);
        
        // Check cache first
        const cached = this.getCachedValue(cleanName);
        if (cached !== null) {
            callback(cached);
            return;
        }
        
        // Try API first, then fallback to hardcoded values
        this.checkItemValueAPI(cleanName, (apiValue) => {
            if (apiValue > 0) {
                this.setCachedValue(cleanName, apiValue);
                callback(apiValue);
            } else {
                const hardcodedValue = this.getHardcodedItemValue(cleanName);
                this.setCachedValue(cleanName, hardcodedValue);
                callback(hardcodedValue);
            }
        });
    }
    
    /**
     * Check item value using CoflNet API
     * @param {string} itemName - Clean item name
     * @param {Function} callback - Callback with value
     */
    checkItemValueAPI(itemName, callback) {
        new Thread(new java.lang.Runnable({
            run: () => {
                try {
                    const coflUrl = "https://sky.coflnet.com/api/auctions/tag/" + 
                                   encodeURIComponent(itemName) + "/sold";
                    const url = new java.net.URL(coflUrl);
                    const connection = url.openConnection();
                    
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("User-Agent", "NoRat-PriceChecker/1.0");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    
                    const responseCode = connection.getResponseCode();
                    
                    if (responseCode === 200) {
                        const reader = new java.io.BufferedReader(
                            new java.io.InputStreamReader(connection.getInputStream())
                        );
                        let response = "";
                        let line;
                        while ((line = reader.readLine()) !== null) {
                            response += line;
                        }
                        reader.close();
                        
                        try {
                            const data = JSON.parse(response);
                            if (data && data.length > 0) {
                                // Get average of recent sales (last 10)
                                let totalValue = 0;
                                let count = Math.min(data.length, 10);
                                for (let i = 0; i < count; i++) {
                                    if (data[i].price) {
                                        totalValue += data[i].price;
                                    }
                                }
                                const avgValue = totalValue / count;
                                Client.scheduleTask(0, () => callback(avgValue));
                                return;
                            }
                        } catch (parseError) {
                            console.error("Error parsing API response:", parseError);
                        }
                    }
                    
                    // API failed, return 0 for fallback
                    Client.scheduleTask(0, () => callback(0));
                    
                } catch (error) {
                    console.error("API request failed:", error);
                    Client.scheduleTask(0, () => callback(0));
                }
            }
        })).start();
    }
    
    /**
     * Get hardcoded item values (fallback)
     * @param {string} itemName - Clean item name
     * @returns {number} Item value in coins
     */
    getHardcodedItemValue(itemName) {
        const lowerName = itemName.toLowerCase();
        
        // Check exact match first
        if (this.rareItems[itemName]) {
            return this.rareItems[itemName];
        }
        
        // Check partial matches
        for (const [item, value] of Object.entries(this.rareItems)) {
            const lowerItem = item.toLowerCase();
            if (lowerName.includes(lowerItem) || lowerItem.includes(lowerName)) {
                return value;
            }
        }
        
        return 0; // Unknown item
    }
    
    /**
     * Load rare items from data file or use hardcoded values
     * @returns {Object} Rare items mapping
     */
    loadRareItems() {
        try {
            // Try to load from data file first
            const rareItemsData = FileLib.read("NoRat", "data/RareItems.json");
            if (rareItemsData) {
                return JSON.parse(rareItemsData);
            }
        } catch (error) {
            console.log("Could not load RareItems.json, using hardcoded values");
        }
        
        // Fallback to hardcoded values
        return {
            "Giant's Sword": 150000000,
            "Necron's Handle": 250000000,
            "Wither Scroll": 35000000,
            "Shadow Assassin Chestplate": 30000000,
            "Livid Dagger": 45000000,
            "Hyperion": 800000000,
            "Valkyrie": 600000000,
            "Astraea": 300000000,
            "Scylla": 400000000,
            "Claymore": 1000000000,
            "Auto Recombobulator": 80000000,
            "Recombobulator 3000": 8000000,
            "Wither Essence": 40000000,
            "Dragon Claw": 25000000,
            "Ender Dragon Pet": 100000000,
            "Phoenix Pet": 200000000,
            "Enderman Pet": 50000000,
            "Griffin Pet": 80000000,
            "Warden Heart": 180000000,
            "Handle": 250000000,
            "Scroll": 35000000,
            "Essence": 30000000,
            "Pet": 25000000,
            "Enchanted Book": 50000000
        };
    }
    
    /**
     * Clean item name for processing
     * @param {string} itemName - Raw item name
     * @returns {string} Cleaned item name
     */
    cleanItemName(itemName) {
        return itemName
            .replace(/§[0-9a-fk-or]/g, '') // Remove color codes
            .replace(/[^\w\s]/g, '') // Remove special characters
            .trim();
    }
    
    /**
     * Get cached value if not expired
     * @param {string} itemName - Item name
     * @returns {number|null} Cached value or null
     */
    getCachedValue(itemName) {
        const cached = this.cache.get(itemName);
        if (!cached) return null;
        
        const now = Date.now();
        if (now - cached.timestamp > this.cacheExpiry) {
            this.cache.delete(itemName);
            return null;
        }
        
        return cached.value;
    }
    
    /**
     * Set cached value with timestamp
     * @param {string} itemName - Item name
     * @param {number} value - Item value
     */
    setCachedValue(itemName, value) {
        this.cache.set(itemName, {
            value: value,
            timestamp: Date.now()
        });
    }
    
    /**
     * Clear cache
     */
    clearCache() {
        this.cache.clear();
    }
}