// features/webhook/WebhookEvents.js - Handles webhook event detection and sending
import { sendMessage, sendError } from "../../utils/chat.js";
import ItemValueChecker from "./ItemValueChecker.js";

export default class WebhookEvents {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.webhookCore = null;
        this.itemChecker = new ItemValueChecker();
        
        this.lastPartyJoinTime = 0;
        this.lastRareDropTime = 0;
        
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("enableWebhook")) return;
        
        // Get webhook core reference (will be set by module loader)
        setTimeout(() => {
            this.webhookCore = global.ModuleLoader?.getFeature("WebhookCore");
        }, 100);
        
        this.registerEventListeners();
        sendMessage("WebhookEvents initialized");
    }
    
    registerEventListeners() {
        // Party join detection
        if (this.settingsManager.getSetting("webhookPartyJoin")) {
            this.registerPartyJoinListeners();
        }
        
        // Rare drop detection  
        if (this.settingsManager.getSetting("webhookRareDrops")) {
            this.registerRareDropListeners();
        }
        
        // Dungeon events (if enabled in future)
        if (this.settingsManager.getSetting("webhookDungeonStart")) {
            this.registerDungeonListeners();
        }
    }
    
    registerPartyJoinListeners() {
        // Primary party join pattern
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("${playerName} joined the party.");
        
        // Alternative party join pattern
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("Party > ${playerName} joined the party!");
        
        // Hypixel party join pattern
        register("chat", (playerName) => {
            this.onPartyJoin(playerName);
        }).setChatCriteria("[Party] ${playerName} joined the party!");
    }
    
    registerRareDropListeners() {
        // Common drop patterns
        register("chat", (itemName) => {
            this.onPotentialRareDrop(itemName);
        }).setChatCriteria("RARE DROP! ${itemName}");
        
        register("chat", (itemName) => {
            this.onPotentialRareDrop(itemName);
        }).setChatCriteria("${itemName} dropped!");
        
        register("chat", (itemName) => {
            this.onPotentialRareDrop(itemName);
        }).setChatCriteria("You found ${itemName}!");
        
        // Pet drop pattern
        register("chat", (petType) => {
            this.onPotentialRareDrop(petType + " Pet");
        }).setChatCriteria("RARE DROP! ${petType} Pet");
        
        // Dungeon chest pattern
        register("chat", (itemName) => {
            this.onPotentialRareDrop(itemName);
        }).setChatCriteria("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ ${itemName}");
    }
    
    registerDungeonListeners() {
        // Dungeon start
        register("chat", () => {
            this.onDungeonStart();
        }).setChatCriteria("Dungeon starts in 1 second.");
        
        // Dungeon complete
        register("chat", () => {
            this.onDungeonComplete();
        }).setChatCriteria("> EXTRA STATS <");
    }
    
    onPartyJoin(playerName) {
        if (!this.webhookCore) return;
        if (!this.settingsManager.getSetting("webhookPartyJoin")) return;
        
        // Cooldown check
        const currentTime = Date.now();
        const cooldown = (this.settingsManager.getSetting("webhookCooldown") || 5) * 1000;
        
        if (currentTime - this.lastPartyJoinTime < cooldown) return;
        this.lastPartyJoinTime = currentTime;
        
        this.sendPartyJoinWebhook(playerName);
    }
    
    sendPartyJoinWebhook(playerName) {
        if (!this.webhookCore) {
            sendError("WebhookCore not available!");
            return;
        }
        
        const payload = {
            content: `**${playerName}** joined your party! :D`
        };
        
        this.webhookCore.sendWebhook(payload, (success) => {
            if (success) {
                sendMessage(`Party join webhook sent for: ${playerName}`);
            } else {
                sendError("Failed to send party join webhook!");
            }
        });
    }
    
    onPotentialRareDrop(itemName) {
        if (!this.webhookCore) return;
        if (!this.settingsManager.getSetting("webhookRareDrops")) return;
        
        // Cooldown check
        const currentTime = Date.now();
        const cooldown = (this.settingsManager.getSetting("webhookCooldown") || 5) * 1000;
        
        if (currentTime - this.lastRareDropTime < cooldown) return;
        
        // Check item value
        this.itemChecker.checkItemValue(itemName, (value) => {
            if (value >= 25000000) { // 25M coins threshold
                this.lastRareDropTime = Date.now();
                this.sendRareDropWebhook(itemName, value);
            }
        });
    }
    
    sendRareDropWebhook(itemName, value) {
        if (!this.webhookCore) {
            sendError("WebhookCore not available!");
            return;
        }
        
        const formattedValue = this.formatCoins(value);
        
        const payload = {
            content: `@everyone **${itemName}** dropped! Worth ~${formattedValue} coins 🎰`
        };
        
        this.webhookCore.sendWebhook(payload, (success) => {
            if (success) {
                sendMessage(`Rare drop webhook sent: ${itemName} (${formattedValue})`);
            } else {
                sendError("Failed to send rare drop webhook!");
            }
        });
    }
    
    onDungeonStart() {
        if (!this.webhookCore) return;
        if (!this.settingsManager.getSetting("webhookDungeonStart")) return;
        
        const payload = {
            content: "🏰 **Dungeon Started!** Good luck!"
        };
        
        this.webhookCore.sendWebhook(payload);
    }
    
    onDungeonComplete() {
        if (!this.webhookCore) return;
        if (!this.settingsManager.getSetting("webhookDungeonComplete")) return;
        
        const payload = {
            content: "✅ **Dungeon Completed!** Check your loot!"
        };
        
        this.webhookCore.sendWebhook(payload);
    }
    
    formatCoins(coins) {
        if (coins >= 1000000000) {
            return (coins / 1000000000).toFixed(1) + "B";
        } else if (coins >= 1000000) {
            return (coins / 1000000).toFixed(1) + "M";
        } else if (coins >= 1000) {
            return (coins / 1000).toFixed(1) + "K";
        } else {
            return coins.toString();
        }
    }
    
    // Test methods for commands
    testPartyJoin() {
        const testName = this.settingsManager.getSetting("testPlayerName") || "TestPlayer";
        this.sendPartyJoinWebhook(testName);
    }
    
    testRareDrop() {
        this.sendRareDropWebhook("Giant's Sword", 150000000);
    }
    
    cleanup() {
        sendMessage("WebhookEvents cleaned up");
    }
}