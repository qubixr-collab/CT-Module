// features/webhook/WebhookCore.js - Core webhook sending functionality
import { sendMessage, sendError, sendSuccess } from "../../utils/chat.js";

export default class WebhookCore {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.lastSendTime = 0;
        this.init();
    }
    
    init() {
        if (!this.settingsManager.getSetting("enableWebhook")) return;
        
        sendMessage("WebhookCore initialized");
    }
    
    /**
     * Send a webhook message
     * @param {Object} payload - The webhook payload
     * @param {Function} callback - Optional callback function
     */
    async sendWebhook(payload, callback = null) {
        const webhookURL = this.settingsManager.getSetting("webhookURL");
        
        if (!webhookURL || webhookURL.trim() === "") {
            sendError("Webhook URL not set!");
            return false;
        }
        
        if (!webhookURL.includes("discord.com/api/webhooks/")) {
            sendError("Invalid Discord webhook URL!");
            return false;
        }
        
        // Check cooldown
        const cooldown = (this.settingsManager.getSetting("webhookCooldown") || 5) * 1000;
        const currentTime = Date.now();
        
        if (currentTime - this.lastSendTime < cooldown) {
            const remaining = Math.ceil((cooldown - (currentTime - this.lastSendTime)) / 1000);
            sendError(`Webhook on cooldown! Wait ${remaining} seconds.`);
            return false;
        }
        
        this.lastSendTime = currentTime;
        
        // Send in separate thread
        return new Promise((resolve) => {
            new Thread(new java.lang.Runnable({
                run: () => {
                    try {
                        const success = this.sendHTTPRequest(webhookURL, payload);
                        
                        Client.scheduleTask(0, () => {
                            if (callback) callback(success);
                            resolve(success);
                        });
                        
                    } catch (error) {
                        Client.scheduleTask(0, () => {
                            sendError("Webhook request failed!");
                            console.error("Webhook error:", error);
                            if (callback) callback(false);
                            resolve(false);
                        });
                    }
                }
            })).start();
        });
    }
    
    /**
     * Send HTTP request to webhook URL
     * @param {string} url - Webhook URL
     * @param {Object} payload - Message payload
     */
    sendHTTPRequest(url, payload) {
        try {
            const urlObj = new java.net.URL(url);
            const connection = urlObj.openConnection();
            
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent", "NoRat-Webhook/1.0");
            connection.setDoOutput(true);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            
            // Add default username and avatar if not provided
            const finalPayload = {
                username: this.settingsManager.getSetting("webhookUsername") || "NoRat Bot",
                avatar_url: this.settingsManager.getSetting("webhookAvatar") || "",
                ...payload
            };
            
            const jsonPayload = JSON.stringify(finalPayload);
            
            const writer = new java.io.OutputStreamWriter(connection.getOutputStream());
            writer.write(jsonPayload);
            writer.flush();
            writer.close();
            
            const responseCode = connection.getResponseCode();
            
            if (responseCode >= 200 && responseCode < 300) {
                return true;
            } else {
                console.error("Webhook HTTP error:", responseCode);
                return false;
            }
            
        } catch (error) {
            console.error("Webhook connection error:", error);
            return false;
        }
    }
    
    /**
     * Send a test message
     */
    sendTestMessage() {
        const x = Math.floor(Player.getX());
        const y = Math.floor(Player.getY());
        const z = Math.floor(Player.getZ());
        
        const payload = {
            content: "**This is a test! Thanks for using NoRat**\nI'm at " + x + " " + y + " " + z
        };
        
        sendMessage("Sending test webhook...");
        
        this.sendWebhook(payload, (success) => {
            if (success) {
                sendSuccess("Test webhook sent successfully!");
                ChatLib.chat("&a[NoRat] &fCheck your Discord server!");
            } else {
                sendError("Failed to send test webhook!");
            }
        });
    }
    
    /**
     * Send a simple message
     * @param {string} message - The message to send
     * @param {Function} callback - Optional callback
     */
    sendSimpleMessage(message, callback = null) {
        const payload = {
            content: message
        };
        
        return this.sendWebhook(payload, callback);
    }
    
    /**
     * Send an embed message
     * @param {Object} embed - Discord embed object
     * @param {string} content - Optional text content
     * @param {Function} callback - Optional callback
     */
    sendEmbed(embed, content = null, callback = null) {
        const payload = {
            embeds: [embed]
        };
        
        if (content) {
            payload.content = content;
        }
        
        return this.sendWebhook(payload, callback);
    }
    
    /**
     * Create a basic embed object
     * @param {string} title - Embed title
     * @param {string} description - Embed description
     * @param {number} color - Embed color (decimal)
     * @param {Array} fields - Array of field objects
     */
    createEmbed(title, description, color = 0x00ff00, fields = []) {
        const embed = {
            title: title,
            description: description,
            color: color,
            timestamp: new Date().toISOString(),
            footer: {
                text: "NoRat Webhook"
            }
        };
        
        if (fields.length > 0) {
            embed.fields = fields;
        }
        
        return embed;
    }
    
    cleanup() {
        sendMessage("WebhookCore cleaned up");
    }
}