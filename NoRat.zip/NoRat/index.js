// index.js - Main Entry Point (Refactored)

// Try-catch around imports to handle missing files gracefully
let ModuleLoader, CommandHandler, SettingsManager;

try {
    // Dynamic imports with error handling - files are in root directory
    const moduleLoaderModule = require("./ModuleLoader.js");
    ModuleLoader = moduleLoaderModule.default || moduleLoaderModule;
} catch (error) {
    console.error("Failed to load ModuleLoader:", error);
    ChatLib.chat("&c[NoRat] Failed to load ModuleLoader!");
}

try {
    const commandHandlerModule = require("./CommandHandler.js");
    CommandHandler = commandHandlerModule.default || commandHandlerModule;
} catch (error) {
    console.error("Failed to load CommandHandler:", error);
    ChatLib.chat("&c[NoRat] Failed to load CommandHandler!");
}

try {
    const settingsManagerModule = require("./SettingsManager.js");
    SettingsManager = settingsManagerModule.default || settingsManagerModule;
} catch (error) {
    console.error("Failed to load SettingsManager:", error);
    ChatLib.chat("&c[NoRat] Failed to load SettingsManager!");
}

// Get version from metadata with error handling
let version = "Unknown";
try {
    const metadata = JSON.parse(FileLib.read("NoRat", "metadata.json"));
    version = metadata.version || "Unknown";
} catch (error) {
    console.error("Failed to read version:", error);
    version = "Unknown";
}

// Initialize the module
const initializeNoRat = () => {
    try {
        // Check if all required classes are loaded
        if (!SettingsManager) {
            ChatLib.chat("&c[NoRat] SettingsManager not loaded!");
            return;
        }
        if (!CommandHandler) {
            ChatLib.chat("&c[NoRat] CommandHandler not loaded!");
            return;
        }
        if (!ModuleLoader) {
            ChatLib.chat("&c[NoRat] ModuleLoader not loaded!");
            return;
        }

        // Initialize core systems
        const settingsManager = new SettingsManager();
        const commandHandler = new CommandHandler(settingsManager);
        const moduleLoader = new ModuleLoader(settingsManager);

        // Make settings globally available for compatibility
        global.settings = settingsManager.getSettings.bind(settingsManager);

        // Make module loader globally available for command handler
        global.ModuleLoader = moduleLoader;
        
        // Load all features
        moduleLoader.loadAllFeatures();
        
        // Register commands
        commandHandler.registerCommands();
        
        // Success message
        ChatLib.chat("");
        ChatLib.chat("&d[NoRat] &a&lhas been loaded! &c&lThanks for using");
        ChatLib.chat("&d[NoRat] &b&lVersion: &f&l" + version);
        ChatLib.chat("");
        
    } catch (error) {
        ChatLib.chat("&c[NoRat] Failed to initialize!");
        ChatLib.chat("&c" + error.toString());
        console.error("NoRat initialization error:", error);
    }
};

// Alternative initialization if ES6 imports don't work
const initializeNoRatFallback = () => {
    try {
        ChatLib.chat("&e[NoRat] Using fallback initialization...");
        
        // Simple fallback - just show that the module is loaded
        ChatLib.chat("");
        ChatLib.chat("&d[NoRat] &a&lhas been loaded! &c&lThanks for using");
        ChatLib.chat("&d[NoRat] &b&lVersion: &f&l" + version);
        ChatLib.chat("&e[NoRat] &7Some features may not be available");
        ChatLib.chat("");
        
    } catch (error) {
        ChatLib.chat("&c[NoRat] Complete initialization failure!");
        console.error("NoRat fallback initialization error:", error);
    }
};

// Start the module with fallback
try {
    initializeNoRat();
} catch (error) {
    console.error("Main initialization failed, trying fallback:", error);
    initializeNoRatFallback();
}