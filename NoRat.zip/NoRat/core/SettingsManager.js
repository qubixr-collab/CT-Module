// core/SettingsManager.js - Centralized settings management
import Settings from "../../Amaterasu/core/Settings";
import DefaultConfig from "../../Amaterasu/core/DefaultConfig";

export default class SettingsManager {
    constructor() {
        this.config = null;
        this.initializeConfig();
    }
    
    initializeConfig() {
        const version = JSON.parse(FileLib.read("NoRat", "metadata.json")).version;
        const CHANGELOG = `# §d§lNoRat v${version}\n${FileLib.read("NoRat", "changelog.md")}`;
        
        // Create default configuration
        const defaultConf = this.createDefaultConfig();
        
        // Initialize settings with the configuration
        this.config = new Settings("NoRat", defaultConf, "data/scheme-vigil.json")
            .addMarkdown("Log", CHANGELOG)
            .setCommand("nr", ["norat"])
            .setPos(10, 25)
            .setSize(80, 50)
            .apply();
    }
    
    createDefaultConfig() {
        const defaultConf = new DefaultConfig("NoRat", "data/settings.json");
        
        // General Settings
        this.addGeneralSettings(defaultConf);
        
        // Cheatos Settings
        this.addCheatosSettings(defaultConf);
        
        // Webhook Settings
        this.addWebhookSettings(defaultConf);
        
        return defaultConf;
    }
    
    addGeneralSettings(config) {
        return config
            // Mana Drain
            .addSwitch({
                category: "General", 
                subcategory: "Notifications", 
                configName: "ManaDrainNotify", 
                title: "Mana Drain Notify", 
                description: "Say how much mana you drained in party chat"
            })
            
            // Waypoints
            .addSlider({
                category: "General", 
                subcategory: "Waypoints", 
                configName: "drawWaypoint", 
                title: "Render Waypoint", 
                description: "Creates waypoints out of patcher formatted coords. Set seconds until waypoints expire or as 0 to turn §4OFF §d(mob waypoints last 1/3 as long).", 
                options: [0, 120], 
                value: 0
            })
            
            // Party Join Sound
            .addSwitch({
                category: "General", 
                subcategory: "Party", 
                configName: "PartyJoinSound", 
                title: "&bParty Join Sound", 
                description: "Play a sound when someone joins your party"
            })
            .addTextInput({
                category: "General", 
                subcategory: "Party", 
                configName: "PartyJoinSoundString", 
                shouldShow: data => data.PartyJoinSound, 
                value: "note.pling", 
                title: "&bParty Join Sound String", 
                description: "E.g random.anvil_land you can search /playSound 1.8.9 for it"
            })
            
            // Wardrobe
            .addSwitch({
                category: "General", 
                subcategory: "Wardrobe", 
                configName: "enableWd", 
                title: "Wardrobe Keybinds", 
                description: "Select keybinds to change armor when inside wardrobe menu"
            })
            .addSwitch({
                category: "General", 
                subcategory: "Wardrobe", 
                configName: "AutoCloseWardrobe", 
                shouldShow: data => data.enableWd, 
                title: "Auto Close Wardrobe", 
                description: "Auto close wardrobe gui when you equip armor"
            })
            .addSwitch({
                category: "General", 
                subcategory: "Wardrobe", 
                configName: "WardrobeSound", 
                shouldShow: data => data.enableWd, 
                title: "&dWardrobe Sound", 
                description: "Play a sound when you equip wardrobe armor"
            })
            .addTextInput({
                category: "General", 
                subcategory: "Wardrobe", 
                configName: "WardrobeSoundString", 
                shouldShow: data => data.enableWd, 
                value: "random.click", 
                title: "&dWardrobe Sound String", 
                description: "E.g random.anvil_land you can search /playSound 1.8.9 for it"
            })
            // Wardrobe keybinds 1-9
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_1", shouldShow: data => data.enableWd, title: "Wardrobe #1", description: "Wardrobe 1 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_2", shouldShow: data => data.enableWd, title: "Wardrobe #2", description: "Wardrobe 2 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_3", shouldShow: data => data.enableWd, title: "Wardrobe #3", description: "Wardrobe 3 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_4", shouldShow: data => data.enableWd, title: "Wardrobe #4", description: "Wardrobe 4 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_5", shouldShow: data => data.enableWd, title: "Wardrobe #5", description: "Wardrobe 5 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_6", shouldShow: data => data.enableWd, title: "Wardrobe #6", description: "Wardrobe 6 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_7", shouldShow: data => data.enableWd, title: "Wardrobe #7", description: "Wardrobe 7 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_8", shouldShow: data => data.enableWd, title: "Wardrobe #8", description: "Wardrobe 8 keybind", value: 0})
            .addKeybind({category: "General", subcategory: "Wardrobe", configName: "wardrobe_9", shouldShow: data => data.enableWd, title: "Wardrobe #9", description: "Wardrobe 9 keybind", value: 0});
    }
    
    addCheatosSettings(config) {
        return config
            // GUI Settings
            .addSwitch({
                category: "Cheatos", 
                subcategory: "GUI", 
                configName: "enableCheatosGUI", 
                title: "&cCheatos GUI", 
                description: "Enable the Cheatos GUI interface"
            })
            .addSwitch({
                category: "Cheatos", 
                subcategory: "GUI", 
                configName: "cheatosOverlay", 
                shouldShow: data => data.enableCheatosGUI, 
                title: "&6GUI Overlay", 
                description: "Show GUI overlay on screen"
            })
            .addSlider({
                category: "Cheatos", 
                subcategory: "GUI", 
                configName: "cheatosOpacity", 
                shouldShow: data => data.enableCheatosGUI, 
                title: "GUI Opacity", 
                description: "Set the opacity of the Cheatos GUI", 
                options: [0, 100], 
                value: 80
            })
            .addColorPicker({
                category: "Cheatos", 
                subcategory: "GUI", 
                configName: "cheatosColor", 
                shouldShow: data => data.enableCheatosGUI, 
                title: "GUI Color", 
                description: "Set the color theme for Cheatos GUI", 
                value: [255, 100, 100, 255]
            })
            .addKeybind({
                category: "Cheatos", 
                subcategory: "GUI", 
                configName: "cheatosToggleKey", 
                shouldShow: data => data.enableCheatosGUI, 
                title: "Toggle Keybind", 
                description: "Keybind to toggle Cheatos GUI", 
                value: 0
            })
            
            // AutoClicker Settings
            .addSwitch({
                category: "Cheatos", 
                subcategory: "AutoClicker", 
                configName: "enableAutoClicker", 
                title: "&cEnable AutoClicker", 
                description: "Enable the AutoClicker module"
            })
            .addDropDown({
                category: "Cheatos", 
                subcategory: "AutoClicker", 
                configName: "autoClickerMode", 
                shouldShow: data => data.enableAutoClicker, 
                title: "Click Mode", 
                description: "Which mouse button to auto click", 
                options: ["Left", "Right", "Both"], 
                value: 0
            })
            .addDropDown({
                category: "Cheatos", 
                subcategory: "AutoClicker", 
                configName: "autoClickerType", 
                shouldShow: data => data.enableAutoClicker, 
                title: "Activation Type", 
                description: "Hold key to click or toggle on/off", 
                options: ["Hold", "Toggle"], 
                value: 1
            })
            .addSlider({
                category: "Cheatos", 
                subcategory: "AutoClicker", 
                configName: "autoClickerCPS", 
                shouldShow: data => data.enableAutoClicker, 
                title: "CPS (Clicks per Second)", 
                description: "How fast to click", 
                options: [1, 20], 
                value: 10
            })
            .addKeybind({
                category: "Cheatos", 
                subcategory: "AutoClicker", 
                configName: "autoClickerKey", 
                shouldShow: data => data.enableAutoClicker, 
                title: "AutoClicker Keybind", 
                description: "Key to activate AutoClicker", 
                value: 0
            });
    }
    
    addWebhookSettings(config) {
        // Note: Webhook button logic will be handled in the WebhookCore feature
        return config
            .addSwitch({
                category: "Webhook", 
                subcategory: "General", 
                configName: "enableWebhook", 
                title: "&aEnable Webhook", 
                description: "Enable webhook functionality"
            })
            .addTextInput({
                category: "Webhook", 
                subcategory: "General", 
                configName: "webhookURL", 
                shouldShow: data => data.enableWebhook, 
                title: "&aWebhook URL", 
                description: "Discord webhook URL for notifications", 
                value: ""
            })
            .addSwitch({
                category: "Webhook", 
                subcategory: "Events", 
                configName: "webhookPartyJoin", 
                shouldShow: data => data.enableWebhook, 
                title: "&aParty Join Notifications", 
                description: "Send webhook notification when someone joins your party"
            })
            .addSwitch({
                category: "Webhook", 
                subcategory: "Events", 
                configName: "webhookRareDrops", 
                shouldShow: data => data.enableWebhook, 
                title: "&aRare Drops", 
                description: "Send webhook notification for rare item drops"
            })
            .addTextInput({
                category: "Webhook", 
                subcategory: "Customization", 
                configName: "webhookUsername", 
                shouldShow: data => data.enableWebhook, 
                title: "&aWebhook Username", 
                description: "Custom username for webhook messages", 
                value: "NoRat Bot"
            })
            .addSlider({
                category: "Webhook", 
                subcategory: "Settings", 
                configName: "webhookCooldown", 
                shouldShow: data => data.enableWebhook, 
                title: "Webhook Cooldown", 
                description: "Cooldown between webhook messages in seconds", 
                options: [0, 60], 
                value: 5
            });
    }
    
    // Getter methods for clean access
    get settings() {
        return this.config.settings;
    }
    
    getSettings() {
        return this.config.settings;
    }
    
    getSetting(key) {
        return this.config.settings[key];
    }
    
    setSetting(key, value) {
        this.config.settings[key] = value;
    }
    
    // Get the config object for GUI access
    getConfig() {
        return this.config;
    }
}