// core/ModuleLoader.js - Handles loading all features
import { sendMessage, sendError } from "../utils/chat.js";

export default class ModuleLoader {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.loadedFeatures = new Map();
        
        // Define all features to load
        this.features = [
            // General features
            { path: "../features/general/ManaDrainNotify.js", name: "ManaDrainNotify" },
            { path: "../features/general/PartyJoinSound.js", name: "PartyJoinSound" },
            { path: "../features/general/Wardrobe.js", name: "Wardrobe" },
            { path: "../features/general/Waypoints.js", name: "Waypoints" },
            
            // Cheatos features
            { path: "../features/cheatos/AutoClicker.js", name: "AutoClicker" },
            { path: "../features/cheatos/CheatosGUI.js", name: "CheatosGUI" },
            
            // Webhook features
            { path: "../features/webhook/WebhookCore.js", name: "WebhookCore" },
            { path: "../features/webhook/WebhookEvents.js", name: "WebhookEvents" },
        ];
    }
    
    async loadAllFeatures() {
        let totalLoadTime = 0;
        let loadedCount = 0;
        let failedCount = 0;
        
        sendMessage("Loading NoRat features...");
        
        for (const feature of this.features) {
            const startTime = Date.now();
            
            try {
                await this.loadFeature(feature);
                
                const loadTime = Date.now() - startTime;
                totalLoadTime += loadTime;
                loadedCount++;
                
                ChatLib.chat(`&a${feature.name} &floaded, took &c${loadTime}ms`);
                
            } catch (error) {
                failedCount++;
                sendError(`Failed to load ${feature.name}: ${error.message}`);
                console.error(`Error loading ${feature.name}:`, error);
            }
        }
        
        // Summary
        ChatLib.chat(`&lLoaded ${loadedCount}/${this.features.length} features in ${totalLoadTime}ms`);
        
        if (failedCount > 0) {
            sendError(`${failedCount} features failed to load!`);
        }
    }
    
    async loadFeature(featureConfig) {
        try {
            const FeatureClass = (await import(featureConfig.path)).default;
            
            if (typeof FeatureClass !== 'function') {
                throw new Error(`${featureConfig.name} does not export a valid class`);
            }
            
            // Initialize the feature with settings access
            const featureInstance = new FeatureClass(this.settingsManager);
            
            // Store for potential cleanup later
            this.loadedFeatures.set(featureConfig.name, featureInstance);
            
            return featureInstance;
            
        } catch (error) {
            throw new Error(`Failed to import ${featureConfig.path}: ${error.message}`);
        }
    }
    
    getFeature(name) {
        return this.loadedFeatures.get(name);
    }
    
    unloadFeature(name) {
        const feature = this.loadedFeatures.get(name);
        if (feature && typeof feature.cleanup === 'function') {
            feature.cleanup();
        }
        this.loadedFeatures.delete(name);
    }
    
    unloadAllFeatures() {
        for (const [name, feature] of this.loadedFeatures) {
            this.unloadFeature(name);
        }
    }
}