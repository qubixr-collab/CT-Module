// core/CommandHandler.js - Handles all NoRat commands
import { sendMessage, sendError, sendSuccess } from "../utils/chat.js";

export default class CommandHandler {
    constructor(settingsManager) {
        this.settingsManager = settingsManager;
        this.commands = new Map();
        this.setupCommands();
    }
    
    setupCommands() {
        // AutoClicker commands
        this.commands.set("ac", this.handleAutoClickerCommand.bind(this));
        this.commands.set("autoclicker", this.handleAutoClickerCommand.bind(this));
        
        // Webhook commands
        this.commands.set("webhook", this.handleWebhookCommand.bind(this));
        this.commands.set("wh", this.handleWebhookCommand.bind(this));
        
        // General commands
        this.commands.set("help", this.handleHelpCommand.bind(this));
        this.commands.set("reload", this.handleReloadCommand.bind(this));
        this.commands.set("version", this.handleVersionCommand.bind(this));
    }
    
    registerCommands() {
        // Main command handler
        register("command", (...args) => {
            this.handleCommand(args);
        }).setName("nr").setAliases(["norat"]);
        
        sendMessage("Commands registered: /nr, /norat");
    }
    
    handleCommand(args) {
        if (args.length === 0) {
            // Open GUI if no arguments
            this.settingsManager.getConfig().openGUI();
            return;
        }
        
        const subCommand = args[0].toLowerCase();
        const commandArgs = args.slice(1);
        
        if (this.commands.has(subCommand)) {
            this.commands.get(subCommand)(commandArgs);
        } else {
            sendError(`Unknown command: ${subCommand}`);
            this.handleHelpCommand();
        }
    }
    
    handleAutoClickerCommand(args) {
        if (!this.settingsManager.getSetting("enableAutoClicker")) {
            sendError("AutoClicker is disabled! Enable it in settings first.");
            return;
        }
        
        if (args.length === 0) {
            this.showAutoClickerHelp();
            return;
        }
        
        const action = args[0].toLowerCase();
        
        switch (action) {
            case "left":
                this.toggleLeftClicker();
                break;
            case "right":
                this.toggleRightClicker();
                break;
            case "both":
                this.toggleBothClickers();
                break;
            case "stop":
                this.stopAllClickers();
                break;
            case "status":
                this.showAutoClickerStatus();
                break;
            default:
                sendError(`Unknown AutoClicker action: ${action}`);
                this.showAutoClickerHelp();
        }
    }
    
    toggleLeftClicker() {
        // This will be handled by the AutoClicker feature
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        if (autoClicker) {
            autoClicker.toggleLeftClicker();
        } else {
            sendError("AutoClicker module not loaded!");
        }
    }
    
    toggleRightClicker() {
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        if (autoClicker) {
            autoClicker.toggleRightClicker();
        } else {
            sendError("AutoClicker module not loaded!");
        }
    }
    
    toggleBothClickers() {
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        if (autoClicker) {
            autoClicker.toggleBothClickers();
        } else {
            sendError("AutoClicker module not loaded!");
        }
    }
    
    stopAllClickers() {
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        if (autoClicker) {
            autoClicker.stopAllClickers();
        } else {
            sendError("AutoClicker module not loaded!");
        }
    }
    
    showAutoClickerStatus() {
        const autoClicker = global.ModuleLoader?.getFeature("AutoClicker");
        if (autoClicker) {
            autoClicker.showStatus();
        } else {
            sendError("AutoClicker module not loaded!");
        }
    }
    
    showAutoClickerHelp() {
        sendMessage("AutoClicker Commands:");
        ChatLib.chat("&7/nr ac left &f- Toggle left clicker");
        ChatLib.chat("&7/nr ac right &f- Toggle right clicker");
        ChatLib.chat("&7/nr ac both &f- Toggle both clickers");
        ChatLib.chat("&7/nr ac stop &f- Stop all clickers");
        ChatLib.chat("&7/nr ac status &f- Show current status");
    }
    
    handleWebhookCommand(args) {
        if (!this.settingsManager.getSetting("enableWebhook")) {
            sendError("Webhook is disabled! Enable it in settings first.");
            return;
        }
        
        if (args.length === 0) {
            this.showWebhookHelp();
            return;
        }
        
        const action = args[0].toLowerCase();
        
        switch (action) {
            case "test":
                this.testWebhook();
                break;
            case "party":
                this.testPartyJoin();
                break;
            case "drop":
                this.testRareDrop();
                break;
            default:
                sendError(`Unknown webhook action: ${action}`);
                this.showWebhookHelp();
        }
    }
    
    testWebhook() {
        const webhookCore = global.ModuleLoader?.getFeature("WebhookCore");
        if (webhookCore) {
            webhookCore.sendTestMessage();
        } else {
            sendError("WebhookCore module not loaded!");
        }
    }
    
    testPartyJoin() {
        const webhookEvents = global.ModuleLoader?.getFeature("WebhookEvents");
        if (webhookEvents) {
            const testName = this.settingsManager.getSetting("testPlayerName") || "TestPlayer";
            webhookEvents.sendPartyJoinWebhook(testName);
        } else {
            sendError("WebhookEvents module not loaded!");
        }
    }
    
    testRareDrop() {
        const webhookEvents = global.ModuleLoader?.getFeature("WebhookEvents");
        if (webhookEvents) {
            webhookEvents.sendRareDropWebhook("Giant's Sword", 150000000);
        } else {
            sendError("WebhookEvents module not loaded!");
        }
    }
    
    showWebhookHelp() {
        sendMessage("Webhook Commands:");
        ChatLib.chat("&7/nr webhook test &f- Send test webhook");
        ChatLib.chat("&7/nr webhook party &f- Test party join notification");
        ChatLib.chat("&7/nr webhook drop &f- Test rare drop notification");
    }
    
    handleHelpCommand() {
        sendMessage("NoRat Commands:");
        ChatLib.chat("&7/nr &f- Open settings GUI");
        ChatLib.chat("&7/nr help &f- Show this help");
        ChatLib.chat("&7/nr version &f- Show version info");
        ChatLib.chat("&7/nr ac <action> &f- AutoClicker commands");
        ChatLib.chat("&7/nr webhook <action> &f- Webhook commands");
        ChatLib.chat("&7/nr reload &f- Reload the module");
    }
    
    handleReloadCommand() {
        sendMessage("Reloading NoRat...");
        try {
            // This would require implementing module reloading
            sendSuccess("NoRat reloaded successfully!");
        } catch (error) {
            sendError("Failed to reload: " + error.message);
        }
    }
    
    handleVersionCommand() {
        const version = JSON.parse(FileLib.read("NoRat", "metadata.json")).version;
        sendMessage(`NoRat Version: &b${version}`);
        ChatLib.chat("&7Created by: &bIQAN");
        ChatLib.chat("&7Description: &fCreated by IQAN_");
    }
}